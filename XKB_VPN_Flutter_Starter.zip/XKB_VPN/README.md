# XKB VPN (Flutter starter)

এটি XKB VPN-এর Android starter project। এতে আছে:
- Messenger hub: WhatsApp, Messenger, Instagram, Telegram-এর অফিসিয়াল ওয়েবসাইট/লিংক খোলে
- DJ Beat Studio UI: প্লে/স্টপ ও ভলিউম কন্ট্রোল
- VPN demo switch: UI-only, আসল VPN নয়
- আপলোড করা ছবিটি `assets/xkb_logo.jpg` হিসেবে রাখা হয়েছে

## প্রয়োজন
- Flutter SDK (stable)
- Android Studio / Android SDK
- Android ফোন বা emulator

## চালানোর নিয়ম
```bash
flutter pub get
flutter run
```

## DJ beat যোগ করা
1. `assets/audio/` ফোল্ডার তৈরি করো।
2. নিজের তৈরি বা ব্যবহারের অনুমতি আছে এমন MP3 ফাইল `assets/audio/dj_beat.mp3` নামে রাখো।
3. `pubspec.yaml`-এ assets অংশে যোগ করো:
```yaml
  assets:
    - assets/xkb_logo.jpg
    - assets/audio/dj_beat.mp3
```
4. `flutter pub get` এবং `flutter run` চালাও।

## APK তৈরি
```bash
flutter build apk --release
```
APK সাধারণত `build/app/outputs/flutter-apk/app-release.apk`-এ তৈরি হবে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- Messenger hub প্রতিটি সার্ভিসের অফিসিয়াল ওয়েবসাইট খোলে; এটি অন্য অ্যাপের private interface-কে একত্র করে না।
- DJ sound শুধু এই অ্যাপের ভিতরে বাজে। Android-এর privacy/audio restrictions-এর কারণে অন্য মেসেঞ্জারের কল অডিওতে স্বয়ংক্রিয়ভাবে সাউন্ড মেশানো সমর্থিত নয়।
- VPN switch বর্তমানে demo state। আসল VPN-এর জন্য Android `VpnService` অথবা WireGuard/OpenVPN-এর মতো পরীক্ষিত implementation এবং একটি বৈধ VPN server/configuration দরকার। এই starter-কে বাস্তব VPN হিসেবে প্রচার করা যাবে না।
- ভলিউম অতিরিক্ত বাড়ালে শ্রবণশক্তির ক্ষতি হতে পারে; নিরাপদ ভলিউম ব্যবহার করো।
