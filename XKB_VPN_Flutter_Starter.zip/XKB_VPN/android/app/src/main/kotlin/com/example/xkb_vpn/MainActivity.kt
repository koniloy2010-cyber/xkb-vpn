package com.example.xkb_vpn

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
