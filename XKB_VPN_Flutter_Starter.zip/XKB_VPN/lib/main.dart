import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(const XkbVpnApp());

const neon = Color(0xFF00E5A8);
const bg = Color(0xFF090D12);
const panel = Color(0xFF151D25);

class XkbVpnApp extends StatelessWidget {
  const XkbVpnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'XKB VPN',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: neon, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  bool vpnRequested = false;

  @override
  Widget build(BuildContext context) {
    final pages = [
      const MessengerPage(),
      const BeatPage(),
      VpnPage(
        enabled: vpnRequested,
        onChanged: (v) => setState(() => vpnRequested = v),
      ),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.bolt, color: neon),
          SizedBox(width: 8),
          Text('XKB VPN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        ]),
        backgroundColor: bg,
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel,
        indicatorColor: neon.withOpacity(.18),
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble, color: neon), label: 'Messenger'),
          NavigationDestination(icon: Icon(Icons.graphic_eq), selectedIcon: Icon(Icons.equalizer, color: neon), label: 'DJ Beats'),
          NavigationDestination(icon: Icon(Icons.shield_outlined), selectedIcon: Icon(Icons.shield, color: neon), label: 'VPN'),
        ],
      ),
    );
  }
}

class MessengerPage extends StatelessWidget {
  const MessengerPage({super.key});

  static const apps = [
    _Messenger('WhatsApp', 'https://www.whatsapp.com/', 'assets/xkb_logo.jpg', Icons.chat),
    _Messenger('Facebook Messenger', 'https://www.messenger.com/', '', Icons.forum),
    _Messenger('Instagram', 'https://www.instagram.com/', '', Icons.camera_alt),
    _Messenger('Telegram', 'https://telegram.org/', '', Icons.send),
  ];

  Future<void> _open(BuildContext context, String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('লিংকটি খোলা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করো।')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: Image.asset('assets/xkb_logo.jpg', height: 180, fit: BoxFit.cover),
        ),
        const SizedBox(height: 20),
        const Text('MESSENGER HUB', style: TextStyle(color: neon, fontSize: 12, letterSpacing: 2, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('তোমার পছন্দের অ্যাপ বেছে নাও', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        ...apps.map((app) => Card(
          color: panel,
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: neon.withOpacity(.12),
              child: Icon(app.icon, color: neon),
            ),
            title: Text(app.name, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('অ্যাপ বা অফিসিয়াল ওয়েবসাইট খোলো'),
            trailing: const Icon(Icons.open_in_new, color: neon),
            onTap: () => _open(context, app.url),
          ),
        )),
        const SizedBox(height: 8),
        const Text(
          'নোট: এই স্ক্রিন থেকে সার্ভিসগুলোর অফিসিয়াল সাইট খোলা হয়। এটি সব মেসেঞ্জারকে এক অ্যাপের ভিতরে লগইন করিয়ে চালানোর ব্যবস্থা নয়।',
          style: TextStyle(color: Colors.white60, fontSize: 12),
        ),
      ],
    );
  }
}

class _Messenger {
  final String name;
  final String url;
  final String asset;
  final IconData icon;
  const _Messenger(this.name, this.url, this.asset, this.icon);
}

class BeatPage extends StatefulWidget {
  const BeatPage({super.key});
  @override
  State<BeatPage> createState() => _BeatPageState();
}

class _BeatPageState extends State<BeatPage> {
  final AudioPlayer player = AudioPlayer();
  double volume = .65;
  bool playing = false;
  String mode = 'DJ Pulse';

  // A bundled original beat is not included; this screen is ready for a licensed audio asset.
  // Add assets/audio/dj_beat.mp3 and declare it in pubspec.yaml to enable playback.
  Future<void> toggle() async {
    if (playing) {
      await player.stop();
      setState(() => playing = false);
      return;
    }
    try {
      await player.setVolume(volume);
      await player.setReleaseMode(ReleaseMode.loop);
      await player.play(AssetSource('audio/dj_beat.mp3'));
      setState(() => playing = true);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('বিট ফাইল যোগ করা হয়নি। README-এর নির্দেশনা দেখো।')),
        );
      }
    }
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(colors: [Color(0xFF123B35), Color(0xFF151D25)]),
            border: Border.all(color: neon.withOpacity(.45)),
          ),
          child: Column(children: [
            const Icon(Icons.graphic_eq, size: 64, color: neon),
            const SizedBox(height: 10),
            const Text('DJ BEAT STUDIO', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(playing ? 'BEAT PLAYING' : 'READY TO PLAY', style: const TextStyle(color: neon, letterSpacing: 2)),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: toggle,
              icon: Icon(playing ? Icons.stop : Icons.play_arrow),
              label: Text(playing ? 'STOP BEAT' : 'PLAY BEAT'),
              style: FilledButton.styleFrom(backgroundColor: neon, foregroundColor: Colors.black),
            ),
          ]),
        ),
        const SizedBox(height: 24),
        const Text('BEAT MODE', style: TextStyle(color: neon, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: mode,
          dropdownColor: panel,
          decoration: const InputDecoration(filled: true, fillColor: panel, border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'DJ Pulse', child: Text('DJ Pulse')),
            DropdownMenuItem(value: 'Bass Rumble', child: Text('Bass Rumble')),
            DropdownMenuItem(value: 'Robot FX', child: Text('Robot FX')),
          ],
          onChanged: (v) => setState(() => mode = v ?? mode),
        ),
        const SizedBox(height: 22),
        Row(children: [
          const Icon(Icons.volume_down),
          const Expanded(child: Text('ভলিউম')),
          Text('${(volume * 100).round()}%'),
        ]),
        Slider(
          value: volume,
          onChanged: (v) async {
            setState(() => volume = v);
            await player.setVolume(v);
          },
          activeColor: neon,
        ),
        const Text(
          'শব্দ নিরাপদ মাত্রায় রাখো। এই বিট শুধু XKB VPN অ্যাপের ভিতরে চলে; অন্য অ্যাপের কল/ভয়েস মেসেজে অটোমেটিকভাবে মেশানো হয় না।',
          style: TextStyle(color: Colors.white60, fontSize: 12),
        ),
      ],
    );
  }
}

class VpnPage extends StatelessWidget {
  final bool enabled;
  final ValueChanged<bool> onChanged;
  const VpnPage({super.key, required this.enabled, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: panel,
            borderRadius: BorderRadius.circular(26),
            border: Border.all(color: neon.withOpacity(.35)),
          ),
          child: Column(children: [
            Icon(enabled ? Icons.shield : Icons.shield_outlined, size: 76, color: neon),
            const SizedBox(height: 12),
            const Text('XKB VPN', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(enabled ? 'DEMO: ON' : 'DISCONNECTED', style: const TextStyle(color: neon, letterSpacing: 2)),
            const SizedBox(height: 18),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('VPN সুইচ (ডেমো)'),
              subtitle: const Text('এটি এখন শুধু UI state পরিবর্তন করে'),
              value: enabled,
              activeColor: neon,
              onChanged: onChanged,
            ),
          ]),
        ),
        const SizedBox(height: 18),
        const Text('প্রকৃত VPN চালু করতে যা লাগবে', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
        const SizedBox(height: 8),
        const Text('• Android VpnService ইন্টিগ্রেশন\n• VPN সার্ভারের ঠিকানা ও অনুমোদিত কনফিগারেশন\n• নিরাপদ কী/অথেনটিকেশন ব্যবস্থাপনা'),
        const SizedBox(height: 12),
        const Text(
          'সতর্কতা: প্রকৃত সার্ভার সংযোগ ছাড়া এই ডেমো ইন্টারনেট ট্রাফিক এনক্রিপ্ট বা IP address পরিবর্তন করে না।',
          style: TextStyle(color: Colors.orangeAccent, fontSize: 12),
        ),
      ],
    );
  }
}
